<script setup>
import { ref, onMounted } from 'vue';
import AddTodo from './AddTodo.vue';
import TodoItem from './TodoItem.vue';
import { useTodoStore } from '../stores/todostore';

const store = useTodoStore();

const { todos } = store;

function addTodo(todo) {
  store.addTodo(todo);
}

function removeTodo(todo) {
  store.removeTodo(todo);
}

function toggleFavorite(todo) {
  store.toggleFavorite(todo);
}

</script>

<template>
   <AddTodo @add-todo="addTodo" />
  <h3 v-if="todos.length" class="mt-4"> Liste des tâches : </h3>
  <ul>
    <TodoItem v-for="(todo,index) in todos"
    :key="index"
    :todo="todo"
    :index="index"
    @remove-todo="removeTodo"
    @toggle-favorite="toggleFavorite"
    />
    
  </ul>
</template>

<style scoped>

</style>
