<script setup>
import TodoList from './components/TodoList.vue';

</script>

<template>
    <header class="bg-light p-3 w-100">
    <div class="d-flex justify-content-center align-items-center gap-2">
      <img src="./assets/piiniia.png" alt="logo pinia" >
      <h1 class="fw-bold mt-3">To Do</h1>
    </div>
    <div>
    </div>
  </header>

 
  <TodoList/>
</template>

<style scoped>

</style>
